defmodule ClientDemo do
   def main do

    Process.register(self(),:main)

    {:ok, pid1} = SocketClient.start_link("user1",5,3,0,1,0) 
    wait_for_join()
    {:ok, pid2} = SocketClient.start_link("user2",5,2,0,1,0) 
    wait_for_join()
    {:ok, pid3} = SocketClient.start_link("user3",5,1,0,1,0)
    wait_for_join() 
    {:ok, pid4} = SocketClient.start_link("user4",5,2,0,1,0)
    wait_for_join() 
    {:ok, pid5} = SocketClient.start_link("user5",5,3,0,1,0) 
    wait_for_join()
    #Process.sleep(1000)
     

    send( pid1 , {:register})
    send( pid2 , {:register})
    send( pid3 , {:register})
    send( pid4 , {:register})
    send( pid5 , {:register})

    receive_register_message(5)
    
    send( pid1 , {:subscribe, "user3"})
    send( pid2 , {:subscribe, "user3"})
    send( pid4 , {:subscribe, "user2"})
    send( pid5 , {:subscribe, "user4"})

    Process.sleep(1000)
    send( pid3, {:tweet,"send message #abc  @user1"})
    
    Process.sleep(1000)
    send( pid1, {:query_hashtag, "abc"})
    send( pid1, {:query_mentions, "user1"})

    send( pid1, {:disconnect})
    Process.sleep(1000)
    send( pid3, {:tweet,"send message #abc1  @user1"})
    send( pid3, {:tweet,"send message #abc2  @user1"})
    send( pid2, {:tweet,"send message #abc3  @user1"})
    Process.sleep(1000)
    send( pid1, {:reconnect})
    
    receive do
        _ -> :ok
    end 

   end

   def wait_for_join() do
    receive do
      {:user_joined} -> :ok
    end
end

   def receive_register_message(0), do: :ok
   def receive_register_message(num) do
     receive do
       {:register_done} -> receive_register_message(num - 1)
        _ -> raise "receive_register_message error!"
     end
   end

end