##########################################################
## This module contains the functonality of the client. ##
## It uses GenSocketClient API which uses genserver.    ##
## Client state has the following :                     ##
## 1) user_name                                         ##
## 2) total_users                                       ##
## 3) user_type                                         ##
## 4) total_recv_count                                  ##
## 5) no_of_rqst                                        ##
## 6) total_sent_count                                  ##
##########################################################

defmodule SocketClient do
    @moduledoc false
    require Logger
    alias Phoenix.Channels.GenSocketClient
    @behaviour GenSocketClient
  
    def start_link(user_name,total_users,user_type,total_recv_count,no_of_rqst,total_sent_count) do
      GenSocketClient.start_link(
            __MODULE__,
            Phoenix.Channels.GenSocketClient.Transport.WebSocketClient,
            ["ws://localhost:4000/socket/websocket", user_name,total_users,user_type,total_recv_count,no_of_rqst,total_sent_count] 
          )
    end
  
    def init([url, user, total_users, user_type, total_recv_count, no_of_rqst, total_sent_count] ) do
      {:connect, url, [], 
      %{first_join: true, ping_ref: 1,user_name: user, total_users: total_users, 
        user_type: user_type, total_recv_tweets: total_recv_count, no_of_rqst: no_of_rqst, total_sent_count: total_sent_count}}
    end
  
    def handle_connected(transport, state) do
        GenSocketClient.join(transport, "Tweeter:*")
      {:ok, state}
    end
  
    def handle_disconnected(reason, state) do
      Logger.error("disconnected: #{inspect reason}")
      Process.send_after(self(), :connect, :timer.seconds(1))
      {:ok, state}
    end
  
    def handle_joined(_topic, _payload, _transport, state) do
      send( :main,  {:user_joined} )
      {:ok, state}
    end
  
    def handle_join_error(topic, payload, _transport, state) do
      Logger.error("join error on the topic #{topic}: #{inspect payload}")
      {:ok, state}
    end
  
    def handle_channel_closed(topic, payload, _transport, state) do
      Logger.error("disconnected from the topic #{topic}: #{inspect payload}")
      Process.send_after(self(), {:join, topic}, :timer.seconds(1))
      {:ok, state}
    end

    ############ server response ###############33

    def handle_message("Tweeter:*", "register", %{"response" => response} , _transport, state) do
        send(:main, {:register_done} )
        Logger.info(response)
        {:ok, state}
    end

    def handle_message("Tweeter:*", "subscribe", %{"response" => response} , _transport, state) do
        Logger.info(response)
        {:ok, state}
    end

    def handle_message("Tweeter:*", "live_feed", payload, transport, state) do
        user_name = Map.get(state, :user_name)
        sender = Map.get(payload, "sender")
        tweet = Map.get(payload, "tweet")
        message = sender<>" tweeted -> "<>tweet
        Logger.info("Live feed for "<>user_name<>" :: "<>message)
        receive_count = Map.get(state, :total_recv_tweets) + 1
        type = Map.get(state, :user_type)

        ### Uncomment to test ClientZDemo
        ##if user_name == "user4", do: GenSocketClient.push(transport, "Tweeter:*", "retweet", %{"user"=>user_name, "messsage"=>"rt: "<>message})
        ###

        ## Comment to test ClientZDemo
        if rem(receive_count,100) == 0 and type == 1, do: 
            GenSocketClient.push(transport, "Tweeter:*", "retweet", %{"user"=>user_name, "messsage"=>"rt:"<>message})
        if rem(receive_count,200) == 0 and type == 2, do: 
            GenSocketClient.push(transport, "Tweeter:*", "retweet", %{"user"=>user_name, "messsage"=>"rt:"<>message})
        if rem(receive_count,300) == 0 and type == 3, do: 
            GenSocketClient.push(transport, "Tweeter:*", "retweet", %{"user"=>user_name, "messsage"=>"rt:"<>message})
        if rem(receive_count,400) == 0 and type == 4, do: 
            GenSocketClient.push(transport, "Tweeter:*", "retweet", %{"user"=>user_name, "messsage"=>"rt:"<>message})
        if rem(receive_count,500) == 0 and type == 5, do: 
            GenSocketClient.push(transport, "Tweeter:*", "retweet", %{"user"=>user_name, "messsage"=>"rt:"<>message})
        ###

        state = Map.put(state, :total_recv_tweets, receive_count )
        {:ok, state}
    end

    def handle_message("Tweeter:*","news_feed", payload, _transport, state) do
        response = Map.get(payload, "response")
        user_name = Map.get(state, :user_name)
        Logger.info("News feed for #{user_name}:: #{response}")
        {:ok, state}
      end
    
    def handle_message(_topic,"hashtag_query", payload, _transport, state) do
        response = Map.get(payload, "response")
        user_name = Map.get(state, :user_name)
        Logger.info("Hashtag query response for #{user_name} :: #{response}")
        {:ok, state}
    end
  
    def handle_message(_topic,"mentions_query", payload, _transport, state) do
        response = Map.get(payload, "response")
        user_name = Map.get(state, :user_name)
        Logger.info("My mentions query for #{user_name} :: #{response}")
        {:ok, state}
    end

    def handle_message("Tweeter:*","reconnect", %{"user"=>user}, _transport, state) do
        Logger.info(user<>" Reconnected")
        {:ok, state}
    end
  
    def handle_message("Tweeter:*","disconnect", %{"user"=>user}, _transport, state) do
        Logger.info(user<>" Disconnected")
        {:ok, state}
    end

    def handle_message(topic, event, payload, _transport, state) do
      Logger.info("message on topic #{topic}: #{event} #{inspect payload}")
      {:ok, state}
    end

    def handle_reply(_topic, _ref, _payload, _transport, state) do
      {:ok, state}
    end
  
    def handle_info(:connect, _transport, state) do
      {:connect, state}
    end

    def handle_info({:join, topic}, transport, state) do
      case GenSocketClient.join(transport, topic) do
        {:error, reason} ->
          Logger.error("error joining the topic #{topic}: #{inspect reason}")
          Process.send_after(self(), {:join, topic}, :timer.seconds(1))
        {:ok, _ref} -> :ok
      end
  
      {:ok, state}
    end
    
    ###### Client functonalities #########################

    def handle_info({:register},transport, state) do
        user_name = Map.get(state, :user_name)
        GenSocketClient.push(transport, "Tweeter:*", "register", %{"user"=>user_name})
        {:ok, state}
    end
    
    def handle_info({:subscribe,followed_user},transport, state) do
        sender = Map.get(state, :user_name)
        GenSocketClient.push(transport, "Tweeter:*", "subscribe", %{"user"=>sender, "followed_user"=>followed_user})
        {:ok, state}
    end

    def handle_info({:tweet, message},transport, state) do
        user_name = Map.get(state, :user_name)
        Logger.info("#{user_name} tweets :: #{message}")
        GenSocketClient.push(transport, "Tweeter:*", "tweet", %{"user"=>user_name, "messsage"=>message})
        {:ok, state}
    end

    def handle_info({:query_hashtag, topic},transport, state) do
        GenSocketClient.push(transport, "Tweeter:*", "hashtag_query", %{"hashtag"=>topic})
        {:ok, state}
    end
  
    def handle_info({:query_mentions, user},transport, state) do
        GenSocketClient.push(transport, "Tweeter:*", "mentions_query", %{"user"=>user})
        {:ok, state}
    end

    def handle_info({:disconnect},transport, state) do
        user_name = Map.get(state, :user_name)
        GenSocketClient.push(transport, "Tweeter:*", "disconnect", %{"user"=>user_name})
        {:ok, state}
    end
  
    def handle_info({:reconnect},transport, state) do
        user_name = Map.get(state, :user_name)
        GenSocketClient.push(transport, "Tweeter:*", "reconnect", %{"user"=>user_name})
        {:ok, state}
    end

    #############################################################################

    ############## ZPF FUNCTONS #####################################33
    
    def handle_info({:start_simulation1,user_name,num}, _transport, state) do
        sub_count = zpf_subscr(user_name, Map.get(state, :user_type), num)
        Process.send_after( self(), {:type1_processes,user_name, num}, 1000) 
        count =  Map.get(state, :total_sent_count)
        state = Map.put(state, :total_sent_count, count+sub_count)
        {:ok,state}
    end

    def handle_info({:start_simulation2,user_name,num}, _transport, state) do
        sub_count = zpf_subscr(user_name, Map.get(state, :user_type), num)
        Process.send_after( self(), {:type2_processes,user_name, num}, 1000)
        count =  Map.get(state, :total_sent_count)
        state = Map.put(state, :total_sent_count, count+sub_count)
        {:ok,state}
    end

    def handle_info({:start_simulation3,user_name,num}, _transport, state) do
        sub_count = zpf_subscr(user_name, Map.get(state, :user_type), num)
        Process.send_after( self(), {:type3_processes,user_name, num}, 1000)
        count =  Map.get(state, :total_sent_count)
        state = Map.put(state, :total_sent_count, count+sub_count)
        {:ok,state}
    end

    def handle_info({:start_simulation4,user_name,num}, _transport, state) do
        sub_count = zpf_subscr(user_name, Map.get(state, :user_type), num)
        Process.send_after( self(), {:type4_processes,user_name, num}, 1000)
        count =  Map.get(state, :total_sent_count)
        state = Map.put(state, :total_sent_count, count+sub_count)
        {:ok,state}
    end

    def handle_info({:start_simulation5,user_name,num}, _transport, state) do
        sub_count = zpf_subscr(user_name, Map.get(state, :user_type), num)
        Process.send_after( self(), {:type5_processes,user_name, num}, 1000)
        count = Map.get(state, :total_sent_count)
        state = Map.put(state, :total_sent_count, count+sub_count)
        {:ok,state}
    end

    def handle_info({:type1_processes,user_name,num},_transport, state) do
        total_recv_count = Map.get(state, :total_recv_tweets)
        total_sent_count = Map.get(state, :total_sent_count)
        no_of_rqst       = Map.get(state, :no_of_rqst)

        send(self() , {:tweet,"Message by "<> user_name})       
        Process.sleep(100)

        mentioned_user = "@user" <> (Enum.random(1..num) |> to_string )        
        send(self() , {:tweet,"Message mention " <> mentioned_user}  )
        Process.sleep(100)
        
        hashtag = "#Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:tweet,"Message about " <> hashtag})
        Process.sleep(100)

        #query my mentons
        send(self(), {:query_mentions, user_name})
        Process.sleep(100)
        
        # query hashtag
        hashtag = "Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:query_hashtag, hashtag})
        Process.sleep(100)

        send(self(), {:disconnect})

        sent_mesg = total_sent_count + 5

        if sent_mesg < no_of_rqst do
            Process.sleep(1000)
            send( self(), {:reconnect})
            state = Map.put(state, :total_sent_count, sent_mesg+1)
            send( self(), {:type1_processes,user_name, num}) 
        else
            send(:main,{:sent_tweets, sent_mesg})
            send(:main,{:rcvd_tweets, total_recv_count})
        end
        {:ok, state}
    end

    def handle_info({:type2_processes,user_name,num},_transport, state) do

        total_recv_count = Map.get(state, :total_recv_tweets)
        total_sent_count = Map.get(state, :total_sent_count)
        no_of_rqst       = Map.get(state, :no_of_rqst)

        send(self() , {:tweet,"Message by "<> user_name})        
        Process.sleep(400)

        mentioned_user = "@user" <> (Enum.random(1..num) |> to_string )        
        send(self() , {:tweet,"Message mention " <> mentioned_user}  ) 
        Process.sleep(400)
        
        hashtag = "#Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:tweet,"Message about " <> hashtag})
        Process.sleep(400)

        # query my mentons
        send(self(), {:query_mentions, user_name})
        Process.sleep(400)
        
        # query hashtag
        hashtag = "Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:query_hashtag, hashtag})
        Process.sleep(400)

        send(self(), {:disconnect})
        
        sent_mesg = total_sent_count + 5
        
        if sent_mesg < no_of_rqst do
            Process.sleep(2000)
            send( self(), {:reconnect})
            state = Map.put(state, :total_sent_count, sent_mesg+1)
            send( self(), {:type1_processes,user_name, num}) 
        else
            send(:main,{:sent_tweets, sent_mesg})
            send(:main,{:rcvd_tweets, total_recv_count})
        end
        {:ok, state}
    end

    def handle_info({:type3_processes,user_name,num},_transport, state) do

        total_recv_count = Map.get(state, :total_recv_tweets)
        total_sent_count = Map.get(state, :total_sent_count)
        no_of_rqst       = Map.get(state, :no_of_rqst)

        send(self() , {:tweet,"Message by "<> user_name})       
        Process.sleep(600)

        mentioned_user = "@user" <> (Enum.random(1..num) |> to_string )        
        send(self() , {:tweet,"Message mention " <> mentioned_user}  ) 
        Process.sleep(600)
        
        hashtag = "#Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:tweet,"Message about " <> hashtag})
        Process.sleep(600)

        # query my mentons
        send(self(), {:query_mentions, user_name})
        Process.sleep(600)
        
        # query hashtag
        hashtag = "Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:query_hashtag, hashtag})
        Process.sleep(600)

        send(self(), {:disconnect})
        
        sent_mesg = total_sent_count + 5
        
        if sent_mesg < no_of_rqst do
            Process.sleep(3000)
            send( self(), {:reconnect})
            state = Map.put(state, :total_sent_count, sent_mesg+1)
            send( self(), {:type1_processes,user_name, num}) 
        else
            send(:main,{:sent_tweets, sent_mesg})
            send(:main,{:rcvd_tweets, total_recv_count})
        end
        {:ok, state}
    end

    def handle_info({:type4_processes,user_name,num},_transport, state) do

        total_recv_count = Map.get(state, :total_recv_tweets)
        total_sent_count = Map.get(state, :total_sent_count)
        no_of_rqst       = Map.get(state, :no_of_rqst)

        send(self() , {:tweet,"Message by "<> user_name})       
        Process.sleep(800)

        mentioned_user = "@user" <> (Enum.random(1..num) |> to_string )        
        send(self() , {:tweet,"Message mention " <> mentioned_user}  )
        Process.sleep(800)
        
        hashtag = "#Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:tweet,"Message about " <> hashtag}) 
        Process.sleep(800)

        # query my mentons
        send(self(), {:query_mentions, user_name})
        Process.sleep(800)
        
        # query hashtag
        hashtag = "Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:query_hashtag, hashtag})
        Process.sleep(800)

        send(self(), {:disconnect})
        
        sent_mesg = total_sent_count + 5
        
        if sent_mesg < no_of_rqst do
            Process.sleep(4000)
            send( self(), {:reconnect})
            state = Map.put(state, :total_sent_count, sent_mesg+1)
            send( self(), {:type1_processes,user_name, num}) 
        else
            send(:main,{:sent_tweets, sent_mesg})
            send(:main,{:rcvd_tweets, total_recv_count})
        end
        {:ok, state}
    end

    
    def handle_info({:type5_processes,user_name,num}, _transport,state) do

        total_recv_count = Map.get(state, :total_recv_tweets)
        total_sent_count = Map.get(state, :total_sent_count)
        no_of_rqst       = Map.get(state, :no_of_rqst)

        send(self() , {:tweet,"Message by "<> user_name})        
        Process.sleep(1000)

        mentioned_user = "@user" <> (Enum.random(1..num) |> to_string )        
        send(self() , {:tweet,"Message mention " <> mentioned_user}  ) 
        Process.sleep(1000)
        
        hashtag = "#Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:tweet,"Message about " <> hashtag}) 
        Process.sleep(1000)

        # query my mentons
        send(self(), {:query_mentions, user_name})
        Process.sleep(1000)
        
        # query hashtag
        hashtag = "Hashtag" <> (Enum.random(1..100) |> to_string )
        send(self() , {:query_hashtag, hashtag})
        Process.sleep(1000)

        send(self(), {:disconnect})
        
        sent_mesg = total_sent_count + 5
        
        if sent_mesg < no_of_rqst do
            Process.sleep(5000)
            send( self(), {:reconnect})
            state = Map.put(state, :total_sent_count, sent_mesg+1)
            send( self(), {:type1_processes,user_name, num}) 
        else
            send(:main,{:sent_tweets, sent_mesg})
            send(:main,{:rcvd_tweets, total_recv_count})
        end
        {:ok, state}
    end


    def handle_info(message, _transport, state) do
        Logger.warn("Unhandled message #{inspect message}")
        {:ok, state}
      end

    def zpf_subscr(user_name, type, num) do
        sub_count = get_subscr_count(type, num)
        {_, n } = String.split_at user_name, 4
        sub_list = Enum.shuffle(1..num) -- [ String.to_integer(n)] |> Enum.slice(0..(sub_count-1))
        Enum.each(sub_list, fn x -> send( String.to_atom("user"<>to_string(x)) ,{:subscribe, user_name}) end)
        sub_count
    end

    ### Uncomment to test ClientZDemo
    #def get_subscr_count(type, num) do
    #    2  
    #end
    ###

    ### Comment to test ClientZDemo 
    def get_subscr_count(type, num) do
        case type do
            1 -> sub_count = round( 0.05 * num ) 
                  if sub_count < 100 do
                        sub_count
                  else
                    100
                  end
            
            2 -> sub_count = round( 0.04 * num ) 
                if sub_count < 80 do
                    sub_count
                  else
                        80
                  end
            
            3 -> sub_count = round( 0.03 * num ) 
                  if sub_count < 60 do
                      sub_count
                    else
                          60
                    end
            
            4 -> sub_count = round( 0.02 * num ) 
                 if sub_count < 40 do
                    sub_count
                  else
                    40
                  end
            
            _ -> 1
                
        end
    end

    def send_message( message ) do
        Process.send( self(), {:send_message,message}, []  )
    end 
end