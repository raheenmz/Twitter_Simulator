defmodule Client do

  def main(args) do

    # add args
    args_list = elem(OptionParser.parse(args),1)
    Process.register(self(),:main)

    num = String.to_integer(Enum.at(args_list,0))
    rqst = String.to_integer(Enum.at(args_list,1))

    # add num_roundoff
    num_roundoff =
    cond do
      rem(num,100) != 0 ->  (Float.ceil( (num/100),0) ) *100 |> round()
      true -> num
    end

    # add rqst_roundoff
    rqst_roundoff =
    cond do
      rem(rqst,100) != 0 ->   (Float.ceil( (rqst/5),0) ) *5 |> round()
      true -> rqst
    end

    generate_client(num_roundoff, rqst_roundoff)
    [total_sent, total_received] = listen_client(2*num, 0, 0)
    Process.sleep(15000)

    IO.puts "\n\n=================================="
    IO.puts     "|| Total tweets sent          : " <> to_string(total_sent)<>"||"
    IO.puts     "|| Total live tweets received : "<> to_string(total_received)<>"||"
    IO.puts     "==================================="
  end

  def listen_client(0,sent,rcvd), do: [sent, rcvd]
  def listen_client(count,sent,rcvd) do
    receive do
      {:sent_tweets, sent_mesg} -> sent = sent + sent_mesg
                                   listen_client(count - 1,sent,rcvd)
      {:rcvd_tweets, rcvd_mesg} -> rcvd = rcvd + rcvd_mesg
                                   listen_client(count - 1,sent,rcvd)
      _ -> raise "listen_client error!"
    end
  end

  def generate_client(num,rqst_count) do

    for n <- 1..num do
        user_name = "user"<>to_string(n)
        type = get_client_type(n, num)
        rqst = get_request_count(type, rqst_count)
        {:ok, pid} = SocketClient.start_link(user_name,num,type,0,rqst,0) ;
        Process.register(pid, String.to_atom(user_name))
        wait_for_join() 
        Process.send_after( pid, {:register}, 100)
    end

    receive_register_message(num) 

    type1 = round( 0.05 * num )
    type2 = round( 0.10 * num ) + type1
    type3 = round( 0.15 * num ) + type2
    type4 = round( 0.25 * num ) + type3
    
    # for each clent n type 1 lst -> call type1 functonaltes
    Enum.each(1..type1        , fn x -> Process.send_after(String.to_atom("user"<>to_string(x)),{:start_simulation1,"user"<>to_string(x),num},1500) end ) 
    Enum.each((type1+1)..type2, fn x -> Process.send_after(String.to_atom("user"<>to_string(x)),{:start_simulation2,"user"<>to_string(x),num},1500) end )
    Enum.each((type2+1)..type3, fn x -> Process.send_after(String.to_atom("user"<>to_string(x)),{:start_simulation3,"user"<>to_string(x),num},1500) end )
    Enum.each((type3+1)..type4, fn x -> Process.send_after(String.to_atom("user"<>to_string(x)),{:start_simulation4,"user"<>to_string(x),num},1500) end )
    Enum.each((type4+1)..num  , fn x -> Process.send_after(String.to_atom("user"<>to_string(x)),{:start_simulation5,"user"<>to_string(x),num},1500) end )

  end

  def get_client_type(n, num) do

    type1_count = round( 0.05 * num )
    type2_count = round( 0.10 * num )
    type3_count = round( 0.15 * num )
    type4_count = round( 0.25 * num )

    cond do
        n <= type1_count -> 1
        n <= type2_count -> 2
        n <= type3_count -> 3
        n <= type4_count -> 4
        true             -> 5
    end
  end

  def get_request_count(type,rqst_count) do
    case type do
        1 -> rqst_count 
        2 -> Float.ceil((rqst_count*0.8),0) |> round()
        3 -> Float.ceil((rqst_count*0.6),0) |> round()
        4 -> Float.ceil((rqst_count*0.4),0) |> round()
        5 -> Float.ceil((rqst_count*0.2),0) |> round()
    end
  end

  def wait_for_join() do
    receive do
      {:user_joined} -> :ok
    end
  end 

  def receive_register_message(0), do: :ok
  def receive_register_message(num) do
    receive do
      {:register_done} -> receive_register_message(num - 1)
       _ -> raise "receive_register_message error!"
    end
  end


end
