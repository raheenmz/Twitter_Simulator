defmodule ServerWeb.LayoutViewTest do
  use ServerWeb.ConnCase, async: true
end
