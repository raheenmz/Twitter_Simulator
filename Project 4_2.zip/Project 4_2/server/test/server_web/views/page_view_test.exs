defmodule ServerWeb.PageViewTest do
  use ServerWeb.ConnCase, async: true
end
