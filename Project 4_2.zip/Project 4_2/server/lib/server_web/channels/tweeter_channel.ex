
defmodule ServerWeb.TweeterChannel do
    use Phoenix.Channel

    def join("Tweeter:*",_payload,socket) do
        {:ok,socket}
    end

    def handle_in("register",%{"user"=>user},socket) do
        :ets.insert(:user_details, {user, socket ,true})
        push socket, "register", %{"response"=>user<>" registered successfully." }
        {:reply, :ok, socket}
    end

    def handle_in("subscribe",%{"user"=>sender, "followed_user"=>followed_user},socket) do
        :ets.insert(:subscriber_table, {followed_user, sender})
        push socket, "subscribe", %{"response"=>sender<>" subscribed to "<>followed_user }
        {:reply, :ok, socket}
    end

    def handle_in("tweet",%{"user"=>user, "messsage"=>message},socket) do
        check_user_mention(message)
        check_hashtags(message)
        subscribers = :ets.match_object(:subscriber_table,{user,:"_"})
        forward_tweets(user,subscribers,message)
        {:noreply,socket}
    end

    def handle_in("retweet",%{"user"=>user, "messsage"=>message},socket) do
        check_user_mention(message)
        check_hashtags(message)
        subscribers = :ets.match_object(:subscriber_table,{user,:"_"})
        forward_tweets(user,subscribers,message)
        {:noreply,socket}
    end

    def handle_in("hashtag_query", %{"hashtag"=>hash_tag},socket) do
        messages = :ets.match(:hashtag_table,{:"_",hash_tag,:"$1"})
        if messages do
            Enum.each(messages,
            fn([x]) -> push socket, "hashtag_query", %{"response"=>x }  end)
        else
            push socket, "hashtag_query", %{"response"=>"No tweet with hashtag "<> hash_tag}
        end
        {:noreply,socket}
    end

    def handle_in("mentions_query", %{"user"=>user},socket) do
        user_tuple = :ets.match(:user_mention_table,{:"_",user,:"$1"})
        if user_tuple do
            Enum.each(user_tuple,
            fn([x]) -> push socket, "mentions_query", %{"response"=> x }  end)
        else
            push socket, "mentions_query", %{"response"=> "No tweet with your mention"}
        end
        {:noreply,socket}
    end

    def handle_in("disconnect", %{"user"=>user} ,socket) do
        [user_tuple] = :ets.match_object(:user_details,{user,:"_",:"_"})
        :ets.insert(:user_details,{elem(user_tuple,0),elem(user_tuple,1),false})
        push socket, "disconnect", %{"user"=>user}
        {:noreply,socket}
    end

    def handle_in("reconnect", %{"user"=>user},socket) do
        [user_tuple] = :ets.match_object(:user_details,{user,:"_",:"_"})
        :ets.insert(:user_details,{elem(user_tuple,0),elem(user_tuple,1),true})
        push socket, "reconnect", %{"user"=>user}
        send_waiting_messages(user,socket)
        {:noreply,socket}
    end

    ###########################################################################################################

    def check_user_mention(message) do
        #IO.inspect("check_user_mention")
        word_list =  String.split(message," ") 
        mentioned_users = Enum.filter(word_list, fn(x) -> String.match?(x, ~r/@/) end)
        Enum.each(mentioned_users, fn(x) -> 
                user_name=String.slice(x, 1..-1)
                user_size=Enum.count(:ets.match_object(:user_mention_table,{:"_",user_name,:"_"}))
                count =
                if(user_size>=100) do
                    msgs=Enum.at(:ets.match_object(:user_mention_table,{:"_",user_name,:"_"}),0)
                    :ets.delete(:user_mention_table,elem(msgs,0))
                    :ets.last(:user_mention_table)+1
                else
                    temp=:ets.last(:user_mention_table)
                    if(is_integer(temp)==true, do: temp+1, else: 0)
                end
                :ets.insert(:user_mention_table,{count,user_name,message})
        end)
    end

    def check_hashtags(message) do
        #IO.inspect("check_hashtags")
        word_list = String.split(message," ")
        hash_tags = Enum.filter(word_list, fn(x) -> String.match?(x, ~r/#/) end)
        Enum.each(hash_tags, fn(x) ->
                user_name=String.slice(x, 1..-1)
                user_size=Enum.count(:ets.match_object(:hashtag_table,{:"_",user_name,:"_"}))
                count=
                if(user_size>=100) do
                    msgs=Enum.at(:ets.match_object(:hashtag_table,{:"_",user_name,:"_"}),0)
                    count_num=elem(msgs,0)
                    :ets.delete(:hashtag_table,count_num)
                    :ets.last(:hashtag_table)+1
                else
                    temp=:ets.last(:hashtag_table)
                    if(is_integer(temp)==true, do: temp+1, else: 0)
                end
                :ets.insert(:hashtag_table,{count,user_name,message})
            end)
    end

    def forward_tweets(sender, subscribers, message) do
        #IO.inspect ("forward_tweets")
        Enum.each(subscribers,
        fn({_,sub_name}) ->      
            [alive_status]=Enum.at(:ets.match(:user_details,{sub_name,:"_",:"$1"}),0)          
            if alive_status == true do
                [socket]=Enum.at(:ets.match(:user_details,{sub_name,:"$1",:"_"}),0)
                push socket, "live_feed", %{"sender" => sender,"tweet"=> message}
            else     
                message = sender<>" tweeted -> "<>message
                :ets.insert(:waiting_table,{sub_name,message})
            end
        end)
    end

    def send_waiting_messages(user_name, socket) do
        all_messages=:ets.lookup(:waiting_table,user_name)
        for i<-all_messages do
            single_message = elem(i,1) 
            push socket, "news_feed" , %{"response"=> single_message}
        end
        :ets.delete(:waiting_table,user_name)
    end

    def disconnected_user_tweets(user, message) do
        IO.inspect("disconnected_user_tweets")
        subscribers = :ets.match_object(:subscriber_table,{user,:"_"})
        Enum.each(subscribers,
        fn({_,sub_name}) ->      
            [alive_status]=Enum.at(:ets.match(:user_details,{sub_name,:"_",:"$1"}),0)          
            if alive_status == false do     
                :ets.insert(:waiting_table,{sub_name,user<>" tweeted ->"<>message})
            end
        end)
    end
end