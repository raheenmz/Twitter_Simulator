defmodule ServerWeb.LayoutView do
  use ServerWeb, :view
end
