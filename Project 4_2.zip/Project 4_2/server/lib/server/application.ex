defmodule Server.Application do
  use Application

  # See https://hexdocs.pm/elixir/Application.html
  # for more information on OTP Applications
  def start(_type, _args) do
    import Supervisor.Spec

    :ets.new(:user_details, [:set, :public, :named_table])
    :ets.new(:subscriber_table, [:bag, :public, :named_table])
    :ets.new(:waiting_table, [:bag, :public, :named_table]) 
    :ets.new(:user_mention_table, [:ordered_set, :public, :named_table])
    :ets.new(:hashtag_table, [:ordered_set, :public, :named_table]) 

    # Define workers and child supervisors to be supervised
    children = [
      # Start the endpoint when the application starts
      supervisor(ServerWeb.Endpoint, []),
      # Start your own worker by calling: Server.Worker.start_link(arg1, arg2, arg3)
      # worker(Server.Worker, [arg1, arg2, arg3]),
    ]

    # See https://hexdocs.pm/elixir/Supervisor.html
    # for other strategies and supported options
    opts = [strategy: :one_for_one, name: Server.Supervisor]
    Supervisor.start_link(children, opts)
  end

  # Tell Phoenix to update the endpoint configuration
  # whenever the application is updated.
  def config_change(changed, _new, removed) do
    ServerWeb.Endpoint.config_change(changed, removed)
    :ok
  end
end
